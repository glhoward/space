% SPACE state-flow example.
%
% This is a deliberately direct implementation of the calibration in the
% note. It uses IRS state-to-state migration flows, backs out the transformed
% weights tilde_w_ij, and maps the population effect of a 0.1 utility increase
% in Illinois.

clear; clc;

% -------------------------------------------------------------------------
% User choices
% -------------------------------------------------------------------------

codeDir = fileparts(mfilename("fullpath"));
flowFile = fullfile(codeDir, "stateinflow1213.csv");
polygonFile = fullfile(codeDir, "shapefiles", "cb_2023_us_state_20m_polygons.csv");

countVar = "n2";        % n2 is people; use n1 for tax returns.
shockFips = "17";      % Illinois.
deltaU = 0.10;         % Utility change in Illinois.
sigma = 3.0;           % Own-population elasticity target from the note.

% -------------------------------------------------------------------------
% Read migration flows and put them in an origin-destination matrix
% -------------------------------------------------------------------------

opts = detectImportOptions(flowFile);
opts = setvartype(opts, ["y2_statefips", "y1_statefips", "y1_state", "y1_state_name"], "string");
flows = readtable(flowFile, opts);

% The IRS file includes aggregate origin codes 96, 97, and 98. These are not
% states, so we drop them from the bilateral migration matrix.
aggregateCodes = ["96", "97", "98"];
stateFips = unique(flows.y2_statefips, "stable");
stateFips = stateFips(~ismember(stateFips, aggregateCodes));
n = numel(stateFips);

stateAbbrev = strings(n, 1);
for i = 1:n
    row = flows(flows.y2_statefips == stateFips(i) & flows.y1_statefips == stateFips(i), :);
    stateAbbrev(i) = erase(row.y1_state_name(1), " Non-migrants");
end

% rawM(i,j) is observed migration from origin i to destination j.
rawM = zeros(n, n);
for r = 1:height(flows)
    origin = flows.y1_statefips(r);
    destination = flows.y2_statefips(r);
    i = find(stateFips == origin, 1);
    j = find(stateFips == destination, 1);
    if ~isempty(i) && ~isempty(j)
        rawM(i, j) = flows.(countVar)(r);
    end
end

% -------------------------------------------------------------------------
% Step 1: Construct symmetric migration objects tilde_m_ij
% -------------------------------------------------------------------------

tildeM = zeros(n, n);
for i = 1:n
    for j = 1:n
        if i == j
            % Non-movers stay on the diagonal.
            tildeM(i, j) = rawM(i, j);
        elseif rawM(i, j) == rawM(j, i)
            tildeM(i, j) = rawM(i, j);
        else
            % Logarithmic mean of the two observed directional flows.
            tildeM(i, j) = (rawM(i, j) - rawM(j, i)) / ...
                (log(rawM(i, j)) - log(rawM(j, i)));
        end
    end
end

% Baseline population and total migration out of each origin.
p = sum(tildeM, 2);
mOut = p - diag(tildeM);

% -------------------------------------------------------------------------
% Step 2: Recover rho_tilde from the calibration matrix M
% -------------------------------------------------------------------------

% M is not a transition matrix. Its diagonal is m_i / p_i, not 1 - m_i / p_i.
M = tildeM ./ p;
for i = 1:n
    M(i, i) = mOut(i) / p(i);
end

[eigVecs, eigVals] = eig(M);
[lambdaMax, idx] = max(real(diag(eigVals)));
rhoTilde = 1 - lambdaMax;

% The associated eigenvector enters only through ratios ell_j / ell_i.
ell = real(eigVecs(:, idx));
if sum(ell) < 0
    ell = -ell;
end
ell = ell / mean(ell);

% -------------------------------------------------------------------------
% Step 3: Recover transformed weights tilde_w_ij
% -------------------------------------------------------------------------

wTilde = zeros(n, n);
for i = 1:n
    for j = 1:n
        if i ~= j
            wTilde(i, j) = tildeM(i, j) / (1 - rhoTilde) * (1 + ell(j) / ell(i));
        end
    end
end

maxPopError = max(abs(sum(wTilde, 2) - p));

% -------------------------------------------------------------------------
% Step 4: Calibrate nu_tilde
% -------------------------------------------------------------------------

avgMigrationRate = mean(mOut ./ p);
nuTilde = sigma / avgMigrationRate;

% -------------------------------------------------------------------------
% Counterfactual: 0.1 utility increase in Illinois
% -------------------------------------------------------------------------

shockIdx = find(stateFips == shockFips, 1);

uHat = ones(n, 1);
uHat(shockIdx) = exp(deltaU);
uHatAlpha = uHat .^ ((1 - rhoTilde) * nuTilde);

pHat = zeros(n, 1);
for i = 1:n
    total = 0;
    for j = 1:n
        if i ~= j
            denominator = wTilde(i, j) * uHatAlpha(i) + wTilde(j, i) * uHatAlpha(j);
            total = total + (wTilde(i, j) / p(i)) * ...
                ((wTilde(i, j) + wTilde(j, i)) / denominator);
        end
    end
    pHat(i) = uHatAlpha(i) * total;
end

pCounter = p .* pHat;
deltaPop = pCounter - p;
pctChange = 100 * (pHat - 1);

% -------------------------------------------------------------------------
% Print diagnostics and make the map
% -------------------------------------------------------------------------

results = table(stateFips, stateAbbrev, p, pCounter, deltaPop, pctChange, ...
    'VariableNames', {'fips', 'state', 'baselinePop', 'counterfactualPop', ...
    'deltaPop', 'pctChange'});

fprintf("SPACE state-flow example\n");
fprintf("Count variable: %s\n", countVar);
fprintf("Shock: +%.3f utility units in %s\n", deltaU, stateAbbrev(shockIdx));
fprintf("rho_tilde = %.6f\n", rhoTilde);
fprintf("average migration rate = %.6f\n", avgMigrationRate);
fprintf("nu_tilde = %.6f\n", nuTilde);
fprintf("max |sum_j w_tilde_ij - p_i| = %.6f\n\n", maxPopError);

disp("Largest population gains:");
gainResults = sortrows(results, "deltaPop", "descend");
disp(gainResults(1:10, :));

disp("Largest population losses:");
lossResults = sortrows(results, "deltaPop", "ascend");
disp(lossResults(1:10, :));

mapFile = fullfile(codeDir, "space_illinois_shock_map.png");
drawPopulationMap(polygonFile, stateFips, pctChange, deltaU, mapFile);
fprintf("Saved population-change map to %s\n", mapFile);

% -------------------------------------------------------------------------
% Small plotting helpers
% -------------------------------------------------------------------------

function drawPopulationMap(polygonFile, stateFips, pctChange, deltaU, mapFile)
    opts = detectImportOptions(polygonFile);
    opts = setvartype(opts, "STATEFP", "string");
    polygons = readtable(polygonFile, opts);
    maxAbs = max(abs(pctChange));
    cmap = orangeWhiteGreen(256);

    closeAfterExport = batchStartupOptionUsed() || ~usejava("desktop");
    visibility = "on";
    if closeAfterExport
        visibility = "off";
    end

    fig = figure("Color", "w", "Position", [100 100 1100 700], "Visible", visibility);
    hold on;
    colormap(cmap);
    caxis([-maxAbs, maxAbs]);

    for i = 1:numel(stateFips)
        fips = stateFips(i);
        if ismember(fips, ["02", "15"])  % Omit Alaska and Hawaii.
            continue
        end
        rows = polygons(polygons.STATEFP == fips, :);
        faceColor = valueToColor(pctChange(i), maxAbs, cmap);
        edgeColor = [0.72 0.72 0.72];
        lineWidth = 0.35;
        if fips == "17"
            edgeColor = [0 0 0];
            lineWidth = 0.9;
        end
        parts = unique(rows.part);
        for q = 1:numel(parts)
            partRows = rows(rows.part == parts(q), :);
            patch(partRows.lon, partRows.lat, faceColor, ...
                "EdgeColor", edgeColor, "LineWidth", lineWidth);
        end
    end
    hold off;

    cb = colorbar;
    cb.Label.String = "Percent population change";
    title(sprintf("Population Change from a +%.2f Utility Shock to Illinois", deltaU), ...
        "FontWeight", "normal");
    text(-88.4, 40.0, "IL", "FontWeight", "bold", "FontSize", 10);
    text(-126, 23.5, "Census 2023 state boundaries; Alaska and Hawaii omitted.", ...
        "FontSize", 9, "Color", [0.35 0.35 0.35]);
    axis equal;
    axis off;
    xlim([-126, -66]);
    ylim([24, 50]);
    exportgraphics(fig, mapFile, "Resolution", 300);
    if closeAfterExport
        close(fig);
    end
end

function colorMap = orangeWhiteGreen(n)
    orange = [0.85 0.37 0.10];
    white = [0.98 0.98 0.96];
    green = [0.10 0.38 0.24];
    half = floor(n / 2);
    lower = [linspace(orange(1), white(1), half)', ...
        linspace(orange(2), white(2), half)', ...
        linspace(orange(3), white(3), half)'];
    upper = [linspace(white(1), green(1), n - half)', ...
        linspace(white(2), green(2), n - half)', ...
        linspace(white(3), green(3), n - half)'];
    colorMap = [lower; upper];
end

function color = valueToColor(value, maxAbs, colorMap)
    scaled = (value + maxAbs) / (2 * maxAbs);
    idx = min(size(colorMap, 1), max(1, round(1 + scaled * (size(colorMap, 1) - 1))));
    color = colorMap(idx, :);
end

function tf = batchStartupOptionUsed()
    try
        desktop = com.mathworks.mde.desk.MLDesktop.getInstance;
        tf = isempty(desktop.getMainFrame);
    catch
        tf = true;
    end
end
