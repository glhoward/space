# Minimal SPACE Replication Files

This folder contains the files needed to run the minimal state-flow example for
the SPACE QSM note.

## Files

- `space_state_example.py`: Python implementation of the calibration and
  Illinois utility-shock counterfactual.
- `space_state_example.m`: MATLAB implementation of the same example.
- `stateinflow1213.csv`: IRS Statistics of Income state-to-state migration
  flows used as the bilateral migration input.
- `shapefiles/cb_2023_us_state_20m_polygons.csv`: preprocessed Census state
  polygon file used only to draw the map.

## Running

Run either script from this folder. Each script expects `stateinflow1213.csv` to
be in the folder root and `cb_2023_us_state_20m_polygons.csv` to be in the
`shapefiles` subfolder.

The Python script uses `numpy`, `pandas`, and `Pillow`. The MATLAB script uses
base MATLAB table, eigenvalue, and graphics commands.
