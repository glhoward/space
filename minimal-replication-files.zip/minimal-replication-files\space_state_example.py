"""SPACE state-flow example.

This is a deliberately direct implementation of the calibration in the note.
It uses IRS state-to-state migration flows, backs out the transformed weights
``tilde_w_ij``, and maps the population effect of a 0.1 utility increase in
Illinois.

Requirements: numpy, pandas, pillow.
"""

from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont


# ---------------------------------------------------------------------
# User choices
# ---------------------------------------------------------------------

CODE_DIR = Path(__file__).resolve().parent
FLOW_FILE = CODE_DIR / "stateinflow1213.csv"
POLYGON_FILE = CODE_DIR / "shapefiles" / "cb_2023_us_state_20m_polygons.csv"

COUNT_VAR = "n2"        # n2 is people; use n1 for tax returns.
SHOCK_FIPS = "17"      # Illinois.
DELTA_U = 0.10         # Utility change in Illinois.
SIGMA = 3.0            # Own-population elasticity target from the note.


# ---------------------------------------------------------------------
# Read migration flows and put them in an origin-destination matrix
# ---------------------------------------------------------------------

flows = pd.read_csv(
    FLOW_FILE,
    dtype={
        "y2_statefips": "string",
        "y1_statefips": "string",
        "y1_state": "string",
        "y1_state_name": "string",
    },
)

# The IRS file includes aggregate origin codes 96, 97, and 98. These are not
# states, so we drop them from the bilateral migration matrix.
aggregate_codes = {"96", "97", "98"}
state_fips = [
    fips for fips in flows["y2_statefips"].drop_duplicates()
    if fips not in aggregate_codes
]
n = len(state_fips)
fips_to_idx = {fips: i for i, fips in enumerate(state_fips)}

state_abbrev = []
for fips in state_fips:
    row = flows[(flows.y2_statefips == fips) & (flows.y1_statefips == fips)].iloc[0]
    state_abbrev.append(row.y1_state_name.replace(" Non-migrants", ""))

# raw_m[i,j] is observed migration from origin i to destination j.
raw_m = np.zeros((n, n))
for row in flows.itertuples(index=False):
    origin = row.y1_statefips
    destination = row.y2_statefips
    if origin in fips_to_idx and destination in fips_to_idx:
        raw_m[fips_to_idx[origin], fips_to_idx[destination]] = getattr(row, COUNT_VAR)


# ---------------------------------------------------------------------
# Step 1: Construct symmetric migration objects tilde_m_ij
# ---------------------------------------------------------------------

tilde_m = np.zeros((n, n))
for i in range(n):
    for j in range(n):
        if i == j:
            # Non-movers stay on the diagonal.
            tilde_m[i, j] = raw_m[i, j]
        elif raw_m[i, j] == raw_m[j, i]:
            tilde_m[i, j] = raw_m[i, j]
        else:
            # Logarithmic mean of the two observed directional flows.
            tilde_m[i, j] = (raw_m[i, j] - raw_m[j, i]) / (
                np.log(raw_m[i, j]) - np.log(raw_m[j, i])
            )

# Baseline population and total migration out of each origin.
p = tilde_m.sum(axis=1)
m_out = p - np.diag(tilde_m)


# ---------------------------------------------------------------------
# Step 2: Recover rho_tilde from the calibration matrix M
# ---------------------------------------------------------------------

# M is not a transition matrix. Its diagonal is m_i / p_i, not 1 - m_i / p_i.
M = tilde_m / p[:, None]
np.fill_diagonal(M, m_out / p)

eig_vals, eig_vecs = np.linalg.eig(M)
idx = np.argmax(eig_vals.real)
lambda_max = eig_vals[idx].real
rho_tilde = 1 - lambda_max

# The associated eigenvector enters only through ratios ell_j / ell_i.
ell = eig_vecs[:, idx].real
if ell.sum() < 0:
    ell = -ell
ell = ell / ell.mean()


# ---------------------------------------------------------------------
# Step 3: Recover transformed weights tilde_w_ij
# ---------------------------------------------------------------------

w_tilde = np.zeros((n, n))
for i in range(n):
    for j in range(n):
        if i != j:
            w_tilde[i, j] = tilde_m[i, j] / (1 - rho_tilde) * (1 + ell[j] / ell[i])

max_pop_error = np.max(np.abs(w_tilde.sum(axis=1) - p))


# ---------------------------------------------------------------------
# Step 4: Calibrate nu_tilde
# ---------------------------------------------------------------------

avg_migration_rate = np.mean(m_out / p)
nu_tilde = SIGMA / avg_migration_rate


# ---------------------------------------------------------------------
# Counterfactual: 0.1 utility increase in Illinois
# ---------------------------------------------------------------------

shock_idx = fips_to_idx[SHOCK_FIPS]

u_hat = np.ones(n)
u_hat[shock_idx] = np.exp(DELTA_U)
u_hat_alpha = u_hat ** ((1 - rho_tilde) * nu_tilde)

p_hat = np.zeros(n)
for i in range(n):
    total = 0.0
    for j in range(n):
        if i == j:
            continue
        denominator = w_tilde[i, j] * u_hat_alpha[i] + w_tilde[j, i] * u_hat_alpha[j]
        total += (w_tilde[i, j] / p[i]) * ((w_tilde[i, j] + w_tilde[j, i]) / denominator)
    p_hat[i] = u_hat_alpha[i] * total

p_counter = p * p_hat
delta_pop = p_counter - p
pct_change = 100 * (p_hat - 1)


# ---------------------------------------------------------------------
# Print diagnostics and make the map
# ---------------------------------------------------------------------

results = pd.DataFrame(
    {
        "fips": state_fips,
        "state": state_abbrev,
        "baselinePop": p,
        "counterfactualPop": p_counter,
        "deltaPop": delta_pop,
        "pctChange": pct_change,
    }
)

print("SPACE state-flow example")
print(f"Count variable: {COUNT_VAR}")
print(f"Shock: +{DELTA_U:.3f} utility units in {state_abbrev[shock_idx]}")
print(f"rho_tilde = {rho_tilde:.6f}")
print(f"average migration rate = {avg_migration_rate:.6f}")
print(f"nu_tilde = {nu_tilde:.6f}")
print(f"max |sum_j w_tilde_ij - p_i| = {max_pop_error:.6f}\n")

print("Largest population gains:")
print(results.sort_values("deltaPop", ascending=False).head(10).to_string(index=False))

print("\nLargest population losses:")
print(results.sort_values("deltaPop").head(10).to_string(index=False))

# ---------------------------------------------------------------------
# Small plotting helpers
# ---------------------------------------------------------------------

def draw_population_map(
    polygon_file: Path,
    state_fips: list[str],
    pct_change: np.ndarray,
    delta_u: float,
    map_file: Path,
) -> None:
    """Draw a simple choropleth using the prebuilt Census polygon CSV."""

    polygons = pd.read_csv(polygon_file, dtype={"STATEFP": "string"})
    change_by_fips = dict(zip(state_fips, pct_change))
    max_abs = float(np.max(np.abs(pct_change)))

    width, height = 1600, 950
    lon_min, lon_max = -126, -66
    lat_min, lat_max = 24, 50
    left, right = 70, 1320
    top, bottom = 130, 830

    def project(lon: float, lat: float) -> tuple[float, float]:
        x = left + (lon - lon_min) / (lon_max - lon_min) * (right - left)
        y = bottom - (lat - lat_min) / (lat_max - lat_min) * (bottom - top)
        return x, y

    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    title_font = load_font(36)
    label_font = load_font(16)

    draw.text(
        (width / 2, 45),
        f"Population Change from a +{delta_u:.2f} Utility Shock to Illinois",
        fill=(20, 20, 20),
        font=title_font,
        anchor="mm",
    )

    for fips, rows in polygons.groupby("STATEFP"):
        if fips not in change_by_fips:
            continue
        face = value_to_color(float(change_by_fips[fips]), max_abs)
        outline = (0, 0, 0) if fips == SHOCK_FIPS else (190, 190, 190)
        width_outline = 2 if fips == SHOCK_FIPS else 1
        for _, part in rows.groupby("part"):
            points = [project(lon, lat) for lon, lat in zip(part.lon, part.lat)]
            if len(points) >= 3:
                draw.polygon(points, fill=face)
                draw.line(points + [points[0]], fill=outline, width=width_outline)

    # Label Illinois using an approximate centroid.
    il_x, il_y = project(-89.2, 40.0)
    draw.text((il_x + 16, il_y - 5), "IL", fill=(0, 0, 0), font=label_font)

    draw.text(
        (left, bottom + 35),
        "Census 2023 state boundaries; Alaska and Hawaii omitted.",
        fill=(90, 90, 90),
        font=load_font(13),
    )

    draw_colorbar(draw, max_abs, x0=1410, y0=125, x1=1460, y1=825, font=label_font)
    image.save(map_file)


def value_to_color(value: float, max_abs: float) -> tuple[int, int, int]:
    """Orange for losses, off-white at zero, forest green for gains."""

    orange = np.array([0.85, 0.37, 0.10])
    white = np.array([0.98, 0.98, 0.96])
    green = np.array([0.10, 0.38, 0.24])
    t = (value + max_abs) / (2 * max_abs)
    t = min(1.0, max(0.0, t))
    color = orange + 2 * t * (white - orange) if t < 0.5 else white + 2 * (t - 0.5) * (green - white)
    return tuple(np.round(255 * color).astype(int))


def draw_colorbar(draw: ImageDraw.ImageDraw, max_abs: float, x0: int, y0: int, x1: int, y1: int, font: ImageFont.ImageFont) -> None:
    """Draw a compact vertical colorbar."""

    for y in range(y0, y1 + 1):
        value = max_abs - 2 * max_abs * (y - y0) / (y1 - y0)
        draw.line([(x0, y), (x1, y)], fill=value_to_color(value, max_abs))
    draw.rectangle([x0, y0, x1, y1], outline=(60, 60, 60), width=2)

    for tick in [-15, -10, -5, 0, 5, 10, 15]:
        y = y1 - (tick + max_abs) / (2 * max_abs) * (y1 - y0)
        draw.line([(x1, y), (x1 + 10, y)], fill=(40, 40, 40), width=2)
        draw.text((x1 + 18, y), f"{tick:g}", fill=(40, 40, 40), font=font, anchor="lm")
    draw.text(((x0 + x1) / 2, y1 + 35), "Percent population change", fill=(20, 20, 20), font=font, anchor="mm")


def load_font(size: int) -> ImageFont.ImageFont:
    """Use Arial when available, with a safe fallback."""

    font_path = Path(r"C:\Windows\Fonts\arial.ttf")
    if font_path.exists():
        return ImageFont.truetype(str(font_path), size=size)
    return ImageFont.load_default()


map_file = CODE_DIR / "space_illinois_shock_map_python.png"
draw_population_map(POLYGON_FILE, state_fips, pct_change, DELTA_U, map_file)
print(f"\nSaved population-change map to {map_file}")
